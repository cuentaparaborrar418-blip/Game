---
name: Golf Ball Factory architecture
description: How the multi-survivor asymmetric game (index.html) is structured so new content only needs registry entries, not code changes.
---

Game lives entirely in `index.html` (single-file canvas game) served by `server.js` on port 5000 via the "Game Server" workflow.

## Core principle
No game/AI/UI logic ever branches on a character's name or id. Everything reads from `CHARACTERS` (survivors) and `KILLERS` (killer) registries:
- `stats`, `abilities` (tagged with a `role`: utility/scout/mobility for survivors, ranged/summon/scan for killer), `passive` (id + hooks consulted generically in `applyDamage`), `celebration` (id + sound), `drawPortrait`.
- Adding a survivor/killer = add one registry entry. Menus (`buildCharacterSelectGrid`), bot generation (`pickRandomCharacterId`), bios (`buildBioGrid`), and AI all iterate the registry automatically.

**Why:** the user explicitly required "no hardcoded name checks anywhere" so future characters/killers scale without touching AI, menus, or damage logic.

## Shared AI
`updateSurvivorAI`/`decideSurvivorGoal` computes a weighted goal (FLEE/RESCUE/HEAL/ITEM_FETCH/GIVE_ITEM/ESCAPE/PATROL) using only ability `role` lookups (`findAbilityByRole`) and archetype multipliers (helper/tactical/coward/juker in `ARCHETYPES`). It never reads `characterId` for decisions, only for cosmetic/portrait purposes.

## Gotchas found during build (fixed)
- Killer entity needs both `meleeCd` (player) and `attackCd` (bot AI) initialized in `createKillerEntity` — bot melee silently no-ops if `attackCd` is missing.
- Any state that "locks" an entity (sword windup, item-use channel, celebrating, DOWN) must be checked consistently in: `checkItemPickups`, `tickItemUsage`, and `applyDamage` (cancel windup/use on hit) — easy to forget one and get contradictory states.
- Bot character variety: `pickRandomCharacterId(usedSet)` must be passed a real accumulating `Set`, not `new Set()` per call, or duplicate-avoidance silently does nothing.
